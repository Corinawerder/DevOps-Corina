package ch.zhaw.iwi.devops.service;

public final class ColorUtility {

	public static final String selected = "pumpkin";
	public static final String notSelected = "asbestos";

}
