package ch.zhaw.iwi.devops;

public class Version {

	private String version = "0.0.2-SNAPSHOT";

	public String getVersion() {
		return version;
	}

}
