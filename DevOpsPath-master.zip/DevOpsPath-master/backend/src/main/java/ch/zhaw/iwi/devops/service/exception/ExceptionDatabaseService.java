package ch.zhaw.iwi.devops.service.exception;

import ch.zhaw.iwi.devops.service.AbstractDatabaseService;

public class ExceptionDatabaseService extends AbstractDatabaseService {

}
