package ch.zhaw.iwi.devops.service.interactionelement.gui;

public class InteractionElementGuiModel {
	
	private String type;
	private boolean newRow;
	
	public String getType() {
		return type;
	}
	
	public void setType(String type) {
		this.type = type;
	}
	
	public boolean isNewRow() {
		return newRow;
	}
	
	public void setNewRow(boolean newRow) {
		this.newRow = newRow;
	}
	
}
