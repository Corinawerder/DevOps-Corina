package ch.zhaw.iwi.devops.service.interactionelement.gui;

public class FormDateFieldElementGuiModel extends FormValueFieldElementGuiModel {

	public FormDateFieldElementGuiModel() {
		super();
		this.setType("date");
	}

}
