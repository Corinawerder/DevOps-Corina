package ch.zhaw.iwi.devops.model.user.permission;

public enum PermissionFunctionEnum {

	readAdministration

}
