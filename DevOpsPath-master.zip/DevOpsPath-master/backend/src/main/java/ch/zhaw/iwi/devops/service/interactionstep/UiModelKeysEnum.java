package ch.zhaw.iwi.devops.service.interactionstep;

public enum UiModelKeysEnum {

	nextInteractionStepPage

}
