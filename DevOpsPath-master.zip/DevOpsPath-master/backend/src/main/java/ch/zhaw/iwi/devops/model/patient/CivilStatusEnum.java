package ch.zhaw.iwi.devops.model.patient;

public enum CivilStatusEnum {

	Ledig,
	Partnerschaft,
	Verheiratet,
	Geschieden
	
}
