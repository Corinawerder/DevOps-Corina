package ch.zhaw.iwi.devops.service;

public class PermissionCheckView {

	@SuppressWarnings("unused")
	private boolean permission;

	public PermissionCheckView(boolean permission) {
		this.permission = permission;
	}
	
}
