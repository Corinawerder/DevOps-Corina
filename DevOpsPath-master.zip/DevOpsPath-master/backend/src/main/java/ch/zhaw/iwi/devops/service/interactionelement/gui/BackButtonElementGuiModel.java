package ch.zhaw.iwi.devops.service.interactionelement.gui;

public class BackButtonElementGuiModel extends InteractionElementGuiModel {

	public BackButtonElementGuiModel() {
		super();
		setType("backbutton");
	}
	
}
