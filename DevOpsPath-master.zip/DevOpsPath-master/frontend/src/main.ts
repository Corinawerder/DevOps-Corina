import {platformBrowserDynamic} from "@angular/platform-browser-dynamic";
import {DevOpsAppModule} from "./app/devops-app.module";

platformBrowserDynamic().bootstrapModule(DevOpsAppModule);
